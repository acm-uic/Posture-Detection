document.addEventListener("DOMContentLoaded", function(){
  // Timer variables and elements
  const controlButton = document.getElementById("controlButton");
  const endButton = document.getElementById("endButton");
  const timerDisplay = document.getElementById("timerDisplay");
  let elapsedTime = 0;
  let timerInterval;
  
  // Update timer display in HH:MM:SS:ms format
  function updateTimerDisplay() {
    const hours = Math.floor(elapsedTime / 3600000);
    const minutes = Math.floor((elapsedTime % 3600000) / 60000);
    const seconds = Math.floor((elapsedTime % 60000) / 1000);
    const milliseconds = elapsedTime % 1000;
    timerDisplay.textContent =
      (hours < 10 ? "0" : "") + hours + ":" +
      (minutes < 10 ? "0" : "") + minutes + ":" +
      (seconds < 10 ? "0" : "") + seconds + ":" +
      (milliseconds < 100 ? (milliseconds < 10 ? "00" : "0") : "") + milliseconds;
  }
  
  // Start timer, updating every 10 milliseconds
  function startTimer() {
    timerInterval = setInterval(() => {
      elapsedTime += 10;
      updateTimerDisplay();
    }, 10);
  }
  
  // Stop timer
  function stopTimer() {
    clearInterval(timerInterval);
  }
  
  // Control button: handles Start, Pause, and Resume functionality
  controlButton.addEventListener("click", function() {
    if (controlButton.textContent === "Start") {
      // Reset and start timer; show End button; change text to Pause
      elapsedTime = 0;
      updateTimerDisplay();
      startTimer();
      controlButton.textContent = "Pause";
      endButton.style.display = "block";
      endButton.disabled = false;
    } else if (controlButton.textContent === "Pause") {
      // Pause timer; change text to Resume
      stopTimer();
      controlButton.textContent = "Resume";
    } else if (controlButton.textContent === "Resume") {
      // Resume timer; change text to Pause
      startTimer();
      controlButton.textContent = "Pause";
    }
  });
  
  // End button: stops timer, resets display, and returns control button to Start
  endButton.addEventListener("click", function() {
    stopTimer();
    elapsedTime = 0;
    updateTimerDisplay();
    controlButton.textContent = "Start";
    endButton.style.display = "none";
  });
  
  // --- Camera Dropdown Functionality ---
  const cameraSelect = document.getElementById("cameraSelect");
  
  // Function to populate available video input devices
  function populateCameraList() {
    // Check if mediaDevices API is available
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      cameraSelect.innerHTML = "<option>No camera support</option>";
      return;
    }
    
    navigator.mediaDevices.enumerateDevices()
      .then(devices => {
        // Filter out video input devices (cameras)
        const videoDevices = devices.filter(device => device.kind === "videoinput");
        videoDevices.forEach((device, index) => {
          const option = document.createElement("option");
          option.value = device.deviceId;
          option.text = device.label || `Camera ${index + 1}`;
          cameraSelect.appendChild(option);
        });
      })
      .catch(error => {
        console.error("Error enumerating devices:", error);
      });
  }
  
  // Call the function to populate the camera dropdown
  populateCameraList();
});
